<?php
/**
 * Debug Credit System
 * Place in plugin root and access via browser to debug credit issues
 * Remove after debugging for security
 */

// Load WordPress
if (!defined('WPINC')) {
    require_once('../../../wp-load.php');
}

// Security check
if (!current_user_can('manage_options')) {
    die('Access denied');
}

echo "<h1>Rakubun AI Credit System Debug</h1>";

// Load required classes
require_once 'includes/class-rakubun-ai-external-api.php';
require_once 'includes/class-rakubun-ai-credits-manager.php';

$user_id = get_current_user_id();

echo "<h2>Current User: $user_id</h2>";

// Check external API status
$external_api = new Rakubun_AI_External_API();
echo "<h3>External API Status:</h3>";
echo "<p>API Token: " . (get_option('rakubun_ai_api_token', '') ? 'Set' : 'Not Set') . "</p>";
echo "<p>Registration Status: " . get_option('rakubun_ai_registration_status', 'Not Registered') . "</p>";
echo "<p>Instance ID: " . get_option('rakubun_ai_instance_id', 'Not Set') . "</p>";
echo "<p>Is Connected: " . ($external_api->is_connected() ? 'Yes' : 'No') . "</p>";

// Check local database
global $wpdb;
$table_name = $wpdb->prefix . 'rakubun_user_credits';

echo "<h3>Local Database:</h3>";
$user_record = $wpdb->get_row($wpdb->prepare(
    "SELECT * FROM $table_name WHERE user_id = %d", 
    $user_id
));

if ($user_record) {
    echo "<p>Local Credits Found:</p>";
    echo "<ul>";
    echo "<li>Article Credits: " . $user_record->article_credits . "</li>";
    echo "<li>Image Credits: " . $user_record->image_credits . "</li>";
    echo "<li>Rewrite Credits: " . ($user_record->rewrite_credits ?? 'Column missing') . "</li>";
    echo "<li>Last Updated: " . $user_record->updated_at . "</li>";
    echo "</ul>";
} else {
    echo "<p>No local credit record found for user $user_id</p>";
}

// Check what get_user_credits returns
echo "<h3>Credits Manager Output:</h3>";
$credits = Rakubun_AI_Credits_Manager::get_user_credits($user_id);
echo "<ul>";
echo "<li>Article Credits: " . $credits['article_credits'] . "</li>";
echo "<li>Image Credits: " . $credits['image_credits'] . "</li>";
echo "<li>Rewrite Credits: " . $credits['rewrite_credits'] . "</li>";
echo "</ul>";

// Check generated content
$content_table = $wpdb->prefix . 'rakubun_generated_content';
$user_content = $wpdb->get_results($wpdb->prepare(
    "SELECT content_type, COUNT(*) as count FROM $content_table WHERE user_id = %d AND status = 'completed' GROUP BY content_type",
    $user_id
));

echo "<h3>Generated Content:</h3>";
if ($user_content) {
    foreach ($user_content as $content) {
        echo "<p>" . ucfirst($content->content_type) . "s generated: " . $content->count . "</p>";
    }
} else {
    echo "<p>No generated content found</p>";
}

// Test credit deduction
echo "<h3>Test Credit Deduction:</h3>";
echo "<p><strong>Before Deduction:</strong></p>";
$before_credits = Rakubun_AI_Credits_Manager::get_user_credits($user_id);
echo "<p>Article Credits: " . $before_credits['article_credits'] . "</p>";

// Test deducting 1 article credit
$deduct_result = Rakubun_AI_Credits_Manager::deduct_credits($user_id, 'article', 1);
echo "<p>Deduction Result: " . ($deduct_result ? 'Success' : 'Failed') . "</p>";

echo "<p><strong>After Deduction:</strong></p>";
$after_credits = Rakubun_AI_Credits_Manager::get_user_credits($user_id);
echo "<p>Article Credits: " . $after_credits['article_credits'] . "</p>";

// Add the credit back
Rakubun_AI_Credits_Manager::add_credits($user_id, 'article', 1);
echo "<p>Credit restored</p>";

echo "<hr>";
echo "<p><strong>Recommendations:</strong></p>";
if ($external_api->is_connected()) {
    echo "<p>⚠️ External API is connected - credits may be managed externally</p>";
    echo "<p>Check external dashboard for actual credit counts</p>";
} else {
    echo "<p>✅ Using local database for credits</p>";
    echo "<p>Credits should be deducted locally when content is generated</p>";
}

echo "<p><small>Delete this file after debugging</small></p>";
?>