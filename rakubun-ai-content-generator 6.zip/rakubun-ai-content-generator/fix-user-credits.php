<?php
/**
 * Fix User Credits Based on Actual Usage
 * Run this once to correct credit counts
 * Delete after use
 */

// Load WordPress
if (!defined('WPINC')) {
    require_once('../../../wp-load.php');
}

// Security check
if (!current_user_can('manage_options')) {
    die('Access denied');
}

echo "<h1>Fix User Credits</h1>";

// Load required classes
require_once 'includes/class-rakubun-ai-credits-manager.php';

$user_id = get_current_user_id();

echo "<h2>Fixing Credits for User: $user_id</h2>";

// Get current usage
global $wpdb;
$content_table = $wpdb->prefix . 'rakubun_generated_content';

$articles_used = $wpdb->get_var($wpdb->prepare(
    "SELECT COUNT(*) FROM $content_table WHERE user_id = %d AND content_type = 'article' AND status = 'completed'",
    $user_id
)) ?: 0;

$images_used = $wpdb->get_var($wpdb->prepare(
    "SELECT COUNT(*) FROM $content_table WHERE user_id = %d AND content_type = 'image' AND status = 'completed'",
    $user_id
)) ?: 0;

echo "<h3>Current Usage:</h3>";
echo "<p>Articles Generated: $articles_used</p>";
echo "<p>Images Generated: $images_used</p>";

// Calculate correct credits (starting from 3 articles, 5 images, 0 rewrites)
$correct_article_credits = max(0, 3 - $articles_used);
$correct_image_credits = max(0, 5 - $images_used);
$correct_rewrite_credits = 0; // Starting amount

echo "<h3>Correct Credits Should Be:</h3>";
echo "<p>Article Credits: $correct_article_credits (3 starting - $articles_used used)</p>";
echo "<p>Image Credits: $correct_image_credits (5 starting - $images_used used)</p>";
echo "<p>Rewrite Credits: $correct_rewrite_credits</p>";

// Update local database
$credits_table = $wpdb->prefix . 'rakubun_user_credits';

// Check if user record exists
$user_record = $wpdb->get_row($wpdb->prepare(
    "SELECT * FROM $credits_table WHERE user_id = %d", 
    $user_id
));

if ($user_record) {
    // Update existing record
    $result = $wpdb->update(
        $credits_table,
        array(
            'article_credits' => $correct_article_credits,
            'image_credits' => $correct_image_credits,
            'rewrite_credits' => $correct_rewrite_credits
        ),
        array('user_id' => $user_id),
        array('%d', '%d', '%d'),
        array('%d')
    );
    
    if ($result !== false) {
        echo "<p>✅ Credits updated successfully in local database</p>";
    } else {
        echo "<p>❌ Failed to update credits: " . $wpdb->last_error . "</p>";
    }
} else {
    // Create new record
    $result = $wpdb->insert(
        $credits_table,
        array(
            'user_id' => $user_id,
            'article_credits' => $correct_article_credits,
            'image_credits' => $correct_image_credits,
            'rewrite_credits' => $correct_rewrite_credits
        ),
        array('%d', '%d', '%d', '%d')
    );
    
    if ($result) {
        echo "<p>✅ New credit record created successfully</p>";
    } else {
        echo "<p>❌ Failed to create credit record: " . $wpdb->last_error . "</p>";
    }
}

// Clear cache
delete_transient('rakubun_ai_credits_' . $user_id);
echo "<p>✅ Credit cache cleared</p>";

// Verify the fix
$updated_credits = Rakubun_AI_Credits_Manager::get_user_credits($user_id);
echo "<h3>Updated Credits (from get_user_credits):</h3>";
echo "<p>Article Credits: " . $updated_credits['article_credits'] . "</p>";
echo "<p>Image Credits: " . $updated_credits['image_credits'] . "</p>";
echo "<p>Rewrite Credits: " . $updated_credits['rewrite_credits'] . "</p>";

echo "<hr>";
echo "<p><strong>Credits have been corrected based on actual usage!</strong></p>";
echo "<p><a href='" . admin_url('admin.php?page=rakubun-ai-content') . "'>Go to Dashboard</a></p>";
echo "<p><small>Remember to delete this file after use.</small></p>";
?>