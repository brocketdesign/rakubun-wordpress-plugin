<?php
/**
 * Database Fix Script for Rakubun AI Plugin
 * 
 * This script can be run to manually fix database issues
 * Place this file in your plugin directory and access it via browser
 * Remove after use for security
 */

// WordPress environment
if (!defined('WPINC')) {
    // Load WordPress if not already loaded
    require_once('../../../wp-load.php');
}

// Security check - only run for administrators
if (!current_user_can('manage_options')) {
    die('Access denied');
}

echo "<h1>Rakubun AI Database Fix</h1>";

// Load plugin classes
require_once 'includes/class-rakubun-ai-activator.php';

echo "<h2>Running Database Fixes...</h2>";

try {
    // Run activation to create/fix tables
    Rakubun_AI_Activator::activate();
    echo "<p>✅ Database tables created/updated successfully</p>";
    
    // Verify tables exist
    global $wpdb;
    $tables_to_check = array(
        $wpdb->prefix . 'rakubun_user_credits',
        $wpdb->prefix . 'rakubun_transactions', 
        $wpdb->prefix . 'rakubun_generated_content',
        $wpdb->prefix . 'rakubun_rewrite_history'
    );
    
    echo "<h3>Table Verification:</h3>";
    foreach ($tables_to_check as $table) {
        $exists = $wpdb->get_var("SHOW TABLES LIKE '$table'");
        if ($exists) {
            echo "<p>✅ Table exists: $table</p>";
        } else {
            echo "<p>❌ Table missing: $table</p>";
        }
    }
    
    // Test credits system
    echo "<h3>Testing Credits System:</h3>";
    $user_id = get_current_user_id();
    
    if ($user_id) {
        require_once 'includes/class-rakubun-ai-credits-manager.php';
        
        $credits = Rakubun_AI_Credits_Manager::get_user_credits($user_id);
        echo "<p>✅ Credits retrieved for user $user_id:</p>";
        echo "<ul>";
        echo "<li>Article Credits: " . $credits['article_credits'] . "</li>";
        echo "<li>Image Credits: " . $credits['image_credits'] . "</li>";
        echo "<li>Rewrite Credits: " . $credits['rewrite_credits'] . "</li>";
        echo "</ul>";
        
        // Test analytics
        $analytics = Rakubun_AI_Credits_Manager::get_user_analytics($user_id);
        echo "<p>✅ Analytics retrieved successfully</p>";
        
        // Test recent content
        $recent = Rakubun_AI_Credits_Manager::get_recent_content($user_id, 5);
        echo "<p>✅ Recent content retrieved: " . count($recent) . " items</p>";
        
        // Test user images
        $images = Rakubun_AI_Credits_Manager::get_user_images($user_id, 10);
        echo "<p>✅ User images retrieved: " . count($images) . " items</p>";
        
    } else {
        echo "<p>⚠️ No user logged in to test credits system</p>";
    }
    
    echo "<h2>✅ All fixes completed successfully!</h2>";
    echo "<p><strong>You can now try accessing the dashboard again.</strong></p>";
    echo "<p><a href='" . admin_url('admin.php?page=rakubun-ai-content') . "'>Go to Dashboard</a></p>";
    
} catch (Exception $e) {
    echo "<p>❌ Error: " . $e->getMessage() . "</p>";
    echo "<p>Check your WordPress error logs for more details.</p>";
}

echo "<hr>";
echo "<p><small>Remember to delete this file after use for security reasons.</small></p>";
?>