<?php
/**
 * Dashboard page template
 */
if (!defined('WPINC')) {
    die;
}
?>

<div class="wrap rakubun-ai-dashboard">
    <h1><?php echo esc_html(get_admin_page_title()); ?></h1>
    
    <div class="rakubun-credits-overview">
        <div class="credits-box">
            <div class="credits-icon">📝</div>
            <div class="credits-info">
                <h2><?php echo esc_html($credits['article_credits']); ?></h2>
                <p>記事生成クレジット残高</p>
            </div>
        </div>
        
        <div class="credits-box">
            <div class="credits-icon">🖼️</div>
            <div class="credits-info">
                <h2><?php echo esc_html($credits['image_credits']); ?></h2>
                <p>画像生成クレジット残高</p>
            </div>
        </div>
    </div>

    <div class="rakubun-quick-actions">
        <h2>クイックアクション</h2>
        <div class="action-buttons">
            <a href="<?php echo admin_url('admin.php?page=rakubun-ai-generate-article'); ?>" class="button button-primary button-large">
                📝 記事を生成
            </a>
            <a href="<?php echo admin_url('admin.php?page=rakubun-ai-generate-image'); ?>" class="button button-primary button-large">
                🎨 画像を生成
            </a>
            <a href="<?php echo admin_url('admin.php?page=rakubun-ai-purchase'); ?>" class="button button-secondary button-large">
                💳 クレジット購入
            </a>
        </div>
    </div>

    <div class="rakubun-info-section">
        <h2>Rakubun AI コンテンツジェネレーターについて</h2>
        <p>このプラグインを使用すると、OpenAIのGPT-4とDALL-Eモデルを使用して高品質な記事と画像を生成できます。</p>
        
        <h3>無料クレジット</h3>
        <ul>
            <li>記事生成 3回分の無料クレジット</li>
            <li>画像生成 5回分の無料クレジット</li>
        </ul>
        
        <h3>はじめ方</h3>
        <ol>
            <li>管理者の方：<a href="<?php echo admin_url('admin.php?page=rakubun-ai-settings'); ?>">設定</a>でOpenAI APIキーとStripeキーを設定してください</li>
            <li>無料クレジットを使ってコンテンツを生成してみましょう</li>
            <li>必要に応じて追加クレジットをご購入ください</li>
        </ol>
    </div>
</div>
